"""Join context errors to preserved task outputs and verify both report files."""
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'runs/0001'
def read(path):
    return json.loads(path.read_text())
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

context = read(ROOT/'context-audit.json')
summary = read(ROOT/'audit-summary.json')
fulltext = read(ROOT/'fulltext-audit.json')
result = read(RUN/'result.json')
manifest = read(RUN/'run.json')
runtime = Path(context['runtime'])
tasks = []
for path in sorted((runtime/'stages').glob('*run_research_task/output.json')):
    for task in read(path).get('task_research_results', []):
        tasks.append((task, str(path.relative_to(ROOT))))
failures = []
for call in context['calls']:
    if not call['confirmed_context_error']:
        continue
    scope = call['scope']
    task, artifact = next((t, p) for t, p in tasks
        if t['task_id'] == scope['task_id'] and t['novelty_point_id'] == scope['point_id'])
    failures.append({'call_id':call['call_id'], 'point_id':scope['point_id'], 'task_id':scope['task_id'],
        'attempt':scope.get('attempt'), 'input_tokens':call['input_tokens'],
        'reserved_output_tokens':call['reserved_output_tokens'],
        'requested_total_tokens':call['requested_total_tokens'], 'context_window':call['context_window'],
        'call_artifact':call['artifact'], 'task_artifact':artifact, 'task_status':task['status'],
        'read_count':len(task['read_results']),
        'body_read_chars':sum(len(r['text']) for r in task['read_results'] if r['role'] != 'abstract'),
        'retained_evidence_cards':len(task['evidence_cards']), 'execution_failures':task['execution_failures'],
        'missing_output':'Normal task completion and final evidence synthesis were not produced; partial observations were preserved. This does not prove a valid card would otherwise have been found.'})
impact = context['workflow_impact']
impact.update(context_related_interruption_observed=any(f['task_status']=='partial' for f in failures),
    context_related_missing_outputs_observed=bool(failures),
    context_related_task_interruptions=failures,
    context_related_missing_report_files=[],
    missing_output_definition='Interrupted research tasks did not produce normal final task synthesis; root result and both reports exist.')
models = dict(Counter(c['model'] for c in context['calls']))
reports = {k:{'path':p, 'exists':Path(p).is_file(), 'size_bytes':Path(p).stat().st_size if Path(p).is_file() else 0}
           for k,p in manifest['rendered_report_paths'].items()}
assert set(reports)=={'default','concise'} and all(x['exists'] and x['size_bytes'] for x in reports.values())
assert set(models)=={'qwen2.5-7b-instruct'}
context['report_exports'] = reports
summary.update(workflow_impact=impact, model_counts=models, cloud_calls=0, report_exports=reports,
    duration_seconds=manifest['duration'])
write(ROOT/'context-audit.json',context)
write(ROOT/'audit-summary.json',summary)
source_manifest=read(RUN/'MF2033k6lC/references/list.json')
body_audit=[]
for reference in fulltext['references']:
    if not reference['acquisition_attempt_count']:
        continue
    record=dict(reference)
    for a in record['body_artifacts']:
        path=RUN/'MF2033k6lC/references'/a['relative_path']
        if path.is_file() and str(a['media_type']).startswith('text/'):
            a['stored_text_chars']=len(path.read_text())
    body_audit.append(record)
findings={
    'context_failure_cases':failures,
    'fulltext_acquired_records':body_audit,
    'fulltext_not_attempted_records':15,
    'fulltext_integrity_note':'Both acquired body artifacts have content_extent=unknown; successful body extraction/read does not certify the complete source paper. Other 15 retained sources had no fulltext request.',
    'extraction_issue':'NP-3 is experimental effectiveness of GSAERU/DSGNN, not an independent technical mechanism; extractor semantic review passed it anyway.',
    'report_quality_issues':[
        {'kind':'acronym_collision','point_id':'NP-3','detail':'Accepted cards cite DSGNN: A Dual-View Supergrid-Aware Graph Neural Network for Regional Air Quality Estimation. This DSGNN is an air-quality model, distinct from the target distributed GNN training framework.'},
        {'kind':'duplicate_document_listing','detail':'Both final evidence cards cite the same title, URL https://arxiv.org/pdf/2404.01975, and exact source quote; concise report lists them as two related documents.'},
        {'kind':'unsupported_feature_attribution','detail':'Reviewer marks the target model performance feature supported by this air-quality abstract; the cited quote describes regional air quality estimation rather than GSAERU performance.'}],
    'review_states':[{'point_id':r['novelty_point_id'],'status':r['status'],'incomplete_reason':r['incomplete_reason'],'verdict':r.get('verdict')} for r in result['novelty_reviews']],
    'historical_reference_cache_note':'91 original references reused cached bootstrap results: 89 failed and 2 not_found. These are historical resolution failures, not new fulltext download failures.',
    'sources':'Original report and runtime artifacts remain unmodified; findings are a separate audit.'}
write(ROOT/'additional-findings.json',findings)
experiment=read(ROOT/'experiment.json')
experiment.update(finished_at=manifest['finished_at'],status=manifest['status'],runtime_run_id=manifest['runtime_run_id'],duration_seconds=manifest['duration'])
write(ROOT/'experiment.json',experiment)
text = f'''MF2033k6lC 完整运行审计
运行目录：{ROOT}
运行耗时：{manifest['duration']:.2f} 秒；主流程状态：{manifest['status']}
模型调用：{len(context['calls'])} 次，全部本地；成功 95 次，失败 2 次，云端 0 次。
上下文溢出：2 次，均为 Researcher 累积 Reader 正文后的模型请求。
- NP-2 / T-1：30095 输入 + 4096 预留输出 = 34191 > 32768；任务 partial，保留正文读取 68834 字符，无证据卡。
- NP-1 / T-R2-COUNT-1：30593 输入 + 4096 预留输出 = 34689 > 32768；任务 partial，保留正文读取 80000 字符，无证据卡。
中断与缺失：2 个调研任务正常完成输出缺失；部分观察已保存。主流程未中断，两版报告都存在。
最终 synthesis：2 次模型调用，无溢出，最大输入加预留输出 14456 tokens。
Reader：36 次读取均成功，其中正文读取 10 次；读取工具成功不等于后续模型能容纳所有原文。
全文获取：17 个研究来源，2 个请求取得可读正文（完整性 unknown），15 个未尝试获取全文。
原论文参考文献：复用历史缓存，91 条中 89 failed、2 not_found；不计作本次下载失败。
结果边界：NP-1、NP-2 均核验未完成；NP-3 仍是实验效果，且存在 DSGNN 同名异义误关联和同篇文献重复列出问题。
报告：default 和 concise，路径见 audit-summary.json。
'''
(ROOT/'audit-summary.txt').write_text(text)
print(json.dumps({'calls':len(context['calls']),'context_failures':len(failures),'reports':reports,'fulltext_counts':fulltext['counts']},ensure_ascii=False))
