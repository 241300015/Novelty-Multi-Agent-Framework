"""Summarize recorded facts; do not infer overflow from generic failures."""
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'runs' / '0001'


def read(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return {}


def summarize():
    manifest = read(RUN / 'run.json')
    runtimes = list((RUN / 'MF2033k6lC' / 'runtime').glob('run-*'))
    runtime = runtimes[0] if runtimes else None
    calls = []
    for path in sorted((runtime / 'llm_calls').glob('*.json')) if runtime else []:
        item = read(path)
        admission = item.get('context_admission') or {}
        error = item.get('error') or {}
        message = str(error.get('message', ''))
        confirmed_overflow = bool(re.search(
            r'maximum context length|context[_ ]length[_ ]exceeded|CONTEXT_LIMIT_EXCEEDED|'
            r'exceeds?[^\n]{0,90}(?:context|maximum)|context[^\n]{0,60}(?:too long|exceed)',
            message, re.I)) or error.get('code') == 'CONTEXT_LIMIT_EXCEEDED'
        payload = item.get('request_payload') or {}
        calls.append({
            'call_id': item.get('llm_call_id'), 'stage': item.get('stage_name'),
            'scope': item.get('scope'), 'model': item.get('model'),
            'status': item.get('status'), 'finish_reason': item.get('finish_reason'),
            'input_tokens': admission.get('input_tokens'),
            'reserved_output_tokens': admission.get('output_tokens_reserved'),
            'requested_total_tokens': admission.get('requested_total_tokens'),
            'context_window': admission.get('effective_context_window'),
            'exact': admission.get('exact', False),
            'context_status': admission.get('status'),
            'context_measurement_verification': item.get('context_measurement_verification'),
            'measured_overflow': admission.get('status') == 'context_limit',
            'confirmed_context_error': confirmed_overflow,
            'error': error or None,
            'output_limit_reached': item.get('finish_reason') == 'length',
            'duration_ms': item.get('duration_ms'),
            'usage': item.get('provider_usage'),
            'artifact': str(path.relative_to(ROOT)),
        })
    stages = []
    if runtime:
        for path in sorted((runtime / 'stages').glob('*/meta.json')):
            stages.append({'artifact': str(path.relative_to(ROOT)), **read(path)})
    report = manifest.get('rendered_report_path')
    result_path = RUN / 'result.json'
    result = read(result_path)
    task_results = []
    observed_queries = Counter()
    if runtime:
        for event_path in (runtime / 'retrieval_events').glob('*.json'):
            event = read(event_path)
            if event.get('phase') == 'provider_query' and event.get('status') == 'SUCCEEDED':
                scope = event.get('scope') or {}
                observed_queries[(scope.get('point_id'), scope.get('task_id'))] += 1
    if runtime:
        for path in sorted((runtime / 'stages').glob('*run_research_task/output.json')):
            for task in read(path).get('task_research_results', []):
                task_results.append({
                    'task_id': task.get('task_id'), 'point_id': task.get('novelty_point_id'), 'status': task.get('status'),
                    'warnings': task.get('warnings'), 'execution_failures': task.get('execution_failures'),
                    'search_count': len(task.get('search_executions', [])),
                    'observed_successful_query_count': observed_queries[(task.get('novelty_point_id'), task.get('task_id'))],
                    'read_count': len(task.get('read_results', [])),
                    'artifact': str(path.relative_to(ROOT)),
                })
    extraction = read(RUN / 'MF2033k6lC' / 'point_extraction_trace.json')
    summary = {
        'run': manifest, 'runtime': str(runtime) if runtime else None,
        'model_call_count': len(calls), 'call_status_counts': dict(Counter(c['status'] for c in calls)),
        'exact_measurement_count': sum(c['exact'] for c in calls),
        'measured_overflow_count': sum(c['measured_overflow'] for c in calls),
        'confirmed_context_error_count': sum(c['confirmed_context_error'] for c in calls),
        'output_limit_reached_count': sum(c['output_limit_reached'] for c in calls),
        'peak_measured_requested_tokens': max((c['requested_total_tokens'] or 0 for c in calls), default=0),
        'artifacts': {
            'novelty_points_exists': (RUN / 'MF2033k6lC' / 'novelty-points.json').is_file(),
            'result_exists': result_path.is_file(),
            'rendered_report_exists': bool(report and Path(report).is_file()),
            'rendered_reports': {k: {'path': v, 'exists': Path(v).is_file()} for k, v in manifest.get('rendered_report_paths', {}).items()},
        },
        'calls': calls, 'stages': stages,
        'task_results': task_results,
        'failure_events': result.get('failure_events', []),
        'workflow_impact': {
            'root_workflow_interrupted': manifest.get('status') in {'FAILED', 'INTERRUPTED'},
            'context_related_failed_calls': sum(c['confirmed_context_error'] and c['status'] != 'SUCCESS' for c in calls),
            'context_related_interruption_observed': False if not any(c['confirmed_context_error'] for c in calls) else None,
            'context_related_missing_outputs_observed': False if not any(c['confirmed_context_error'] for c in calls) else None,
            'evidence_card_count': len(result.get('evidence_cards', [])),
            'point_lifecycle': result.get('report', {}).get('point_lifecycle', []),
            'extraction_coverage_complete': extraction.get('coverage_complete'),
            'extraction_read_chars': sum(len(x.get('text', '')) for x in extraction.get('reading', {}).get('reads', [])),
            'extraction_unread_segments': len(extraction.get('reading', {}).get('unread_segments', [])),
        },
        'interpretation': 'Measured overflow, explicit provider/context rejection, and generation output limit are separate facts. Missing downstream output is attributed to context only when the recorded failure chain supports it.',
    }
    (ROOT / 'context-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in {'calls', 'stages', 'interpretation'}}, ensure_ascii=False))
    return summary


if __name__ == '__main__':
    summarize()
