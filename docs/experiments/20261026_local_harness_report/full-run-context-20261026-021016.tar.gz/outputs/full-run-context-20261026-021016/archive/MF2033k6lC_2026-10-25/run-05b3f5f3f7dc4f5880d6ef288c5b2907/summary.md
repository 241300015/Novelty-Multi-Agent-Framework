# Runtime Summary

## Run

Paper ID: MF2033k6lC
Run ID: run-05b3f5f3f7dc4f5880d6ef288c5b2907
Entrypoint: paper_input
Input Identity: {"paper_json": "outputs/MF2033k6lC/paper-input/others/paper.json", "paper_sha256": "89fcc578efcc840daa9c4e0698943314f794e096e176c067dbbd6e603d42ea66", "novelty_point_id": null, "task_id": null, "search_plan_id": null}
Status: SUCCESS
Start: 2026-10-25T18:10:27.061212+00:00
End: 2026-10-25T18:15:56.559171+00:00
Duration: 329527 ms

## Environment

Git Branch: feat/p0-07-concise-report
Git Commit: 1f8a474d755d2997e9aa9106e8c8d3d059c29cd2
Model: openai_compatible / qwen2.5-7b-instruct
Python: 3.11.16

## Stage Status

| Stage | Status | Duration |
|---|---|---:|
| extract_points | SUCCESS | 20674 ms |
| plan | SUCCESS | 0 ms |
| dispatch_planning_tasks | SUCCESS | 0 ms |
| plan_research_task | SUCCESS | 6103 ms |
| dispatch_research_tasks | SUCCESS | 0 ms |
| run_research_task | SUCCESS | 77291 ms |
| validate_evidence | SUCCESS | 11 ms |
| review_evidence | SUCCESS | 56567 ms |
| validate_synthesis_input | SUCCESS | 4 ms |
| check_final_evidence_sufficiency | SUCCESS | 3 ms |
| plan_supplement | SUCCESS | 7455 ms |
| dispatch_planning_tasks | SUCCESS | 0 ms |
| plan_research_task | SUCCESS | 5966 ms |
| dispatch_research_tasks | SUCCESS | 0 ms |
| run_research_task | SUCCESS | 78463 ms |
| validate_evidence | SUCCESS | 11 ms |
| review_evidence | SUCCESS | 62021 ms |
| validate_synthesis_input | SUCCESS | 3 ms |
| check_final_evidence_sufficiency | SUCCESS | 2 ms |
| synthesize_report | SUCCESS | 14437 ms |
| validate_report_integrity | SUCCESS | 0 ms |
| persist_report | SUCCESS | 6 ms |
| render_report | SUCCESS | 9 ms |

## Tool Calls

| Tool | Calls | Success | Failed | Empty |
|---|---:|---:|---:|---:|
| database_search | 2 | 2 | 0 | 0 |
| reader | 16 | 16 | 0 | 0 |

## Runtime Diagnostics

| Diagnostic | Status | Calls | Failed | Primary finding | Detail |
|---|---|---:|---:|---|---|
| reader | OK | 16 | 0 | - | `diagnostics/reader.json` |
| reference_namespace | ERROR | 16 | 0 | - | `diagnostics/reference_namespace.json` |
| reviewer | WARNING | 0 | 0 | - | `diagnostics/reviewer.json` |

## Run Outcome

- None

## LLM Token Usage and Cost

Calls: 50
Input tokens: 335571
Cached input tokens: 0
Output tokens: 8516
Reasoning tokens: 0
Total tokens: 344087
Estimated API cost (RMB): Unknown (priced subtotal 0.00000000)
Cost completeness: PARTIAL

| Model | Calls | Input | Cached | Output | Total | Cost (RMB) | Unpriced |
|---|---:|---:|---:|---:|---:|---:|---:|
| qwen2.5-7b-instruct | 50 | 335571 | 0 | 8516 | 344087 | Unknown (priced subtotal 0.00000000) | 50 |

## Final Evidence Sufficiency Checks

### Round 1

Configured cut: 1
Stage status: SUCCESS
Check status: PASS
Input final valid Cards: 1
Ignored Cards: 0
Output matches calculation: True
Round limit allows supplement: True
Actual next stage: plan_supplement

| Novelty Point | Valid Cards | Required Cards | Status |
|---|---:|---:|---|
| NP-1 | 1 | 1 | PASS |

### Round 2

Configured cut: 1
Stage status: SUCCESS
Check status: PASS
Input final valid Cards: 1
Ignored Cards: 0
Output matches calculation: True
Round limit allows supplement: False
Actual next stage: synthesize_report

| Novelty Point | Valid Cards | Required Cards | Status |
|---|---:|---:|---|
| NP-1 | 1 | 1 | PASS |


## Reviewer Information Adjudication

### Stage stage_0008

Stage status: SUCCESS
Cards preserved: True
Supplement requests control route: False
Missing reviews: []
Unexpected reviews: []
Duplicate reviews: []
Unresolved Evidence IDs: []
Actual next stage: validate_synthesis_input

| Novelty Point | Status | Verdict | Relevant Works | Supplement |
|---|---|---|---:|---|
| NP-1 | insufficient_evidence | - | 1 | True |

### Stage stage_0017

Stage status: SUCCESS
Cards preserved: True
Supplement requests control route: False
Missing reviews: []
Unexpected reviews: []
Duplicate reviews: []
Unresolved Evidence IDs: []
Actual next stage: validate_synthesis_input

| Novelty Point | Status | Verdict | Relevant Works | Supplement |
|---|---|---|---:|---|
| NP-1 | reviewed | partially_novel | 1 | True |


## Errors

- None

## Integrity Gates

- validate_evidence: PASS
- validate_synthesis_input: PASS
- validate_evidence: PASS
- validate_synthesis_input: PASS
- validate_report_integrity: PASS

## Last Completed Stage

render_report
