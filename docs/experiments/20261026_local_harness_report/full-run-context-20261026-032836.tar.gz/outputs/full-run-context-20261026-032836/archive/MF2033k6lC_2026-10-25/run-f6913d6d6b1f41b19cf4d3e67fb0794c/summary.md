# Runtime Summary

## Run

Paper ID: MF2033k6lC
Run ID: run-f6913d6d6b1f41b19cf4d3e67fb0794c
Entrypoint: paper_input
Input Identity: {"paper_json": "outputs/MF2033k6lC/paper-input/others/paper.json", "paper_sha256": "89fcc578efcc840daa9c4e0698943314f794e096e176c067dbbd6e603d42ea66", "novelty_point_id": null, "task_id": null, "search_plan_id": null}
Status: SUCCESS
Start: 2026-10-25T19:28:46.755857+00:00
End: 2026-10-25T19:36:24.488625+00:00
Duration: 457766 ms

## Environment

Git Branch: feat/p0-07-concise-report
Git Commit: 1f8a474d755d2997e9aa9106e8c8d3d059c29cd2
Model: openai_compatible / qwen2.5-7b-instruct
Python: 3.11.16

## Stage Status

| Stage | Status | Duration |
|---|---|---:|
| extract_points | SUCCESS | 52526 ms |
| plan | SUCCESS | 0 ms |
| dispatch_planning_tasks | SUCCESS | 0 ms |
| plan_research_task | SUCCESS | 5551 ms |
| plan_research_task | SUCCESS | 6609 ms |
| plan_research_task | SUCCESS | 7195 ms |
| dispatch_research_tasks | SUCCESS | 0 ms |
| run_research_task | SUCCESS | 105316 ms |
| run_research_task | SUCCESS | 159793 ms |
| run_research_task | SUCCESS | 118812 ms |
| validate_evidence | SUCCESS | 11 ms |
| review_evidence | SUCCESS | 8 ms |
| validate_synthesis_input | SUCCESS | 3 ms |
| check_final_evidence_sufficiency | SUCCESS | 2 ms |
| plan_supplement | SUCCESS | 16990 ms |
| dispatch_planning_tasks | SUCCESS | 0 ms |
| plan_research_task | SUCCESS | 6932 ms |
| plan_research_task | SUCCESS | 7722 ms |
| plan_research_task | SUCCESS | 6885 ms |
| dispatch_research_tasks | SUCCESS | 0 ms |
| run_research_task | SUCCESS | 130949 ms |
| run_research_task | SUCCESS | 137521 ms |
| run_research_task | SUCCESS | 138470 ms |
| validate_evidence | SUCCESS | 16 ms |
| review_evidence | SUCCESS | 43259 ms |
| validate_synthesis_input | SUCCESS | 3 ms |
| check_final_evidence_sufficiency | SUCCESS | 2 ms |
| synthesize_report | SUCCESS | 30996 ms |
| validate_report_integrity | SUCCESS | 0 ms |
| persist_report | SUCCESS | 6 ms |
| render_report | SUCCESS | 13 ms |

## Tool Calls

| Tool | Calls | Success | Failed | Empty |
|---|---:|---:|---:|---:|
| database_search | 8 | 8 | 0 | 1 |
| reader | 36 | 36 | 0 | 0 |

## Runtime Diagnostics

| Diagnostic | Status | Calls | Failed | Primary finding | Detail |
|---|---|---:|---:|---|---|
| reader | OK | 36 | 0 | - | `diagnostics/reader.json` |
| reference_namespace | ERROR | 36 | 0 | - | `diagnostics/reference_namespace.json` |
| reviewer | WARNING | 0 | 0 | - | `diagnostics/reviewer.json` |

## Run Outcome

- None

## LLM Token Usage and Cost

Calls: 97
Input tokens: 715902
Cached input tokens: 0
Output tokens: 9659
Reasoning tokens: 0
Total tokens: 725561
Estimated API cost (RMB): Unknown (priced subtotal 0.00000000)
Cost completeness: PARTIAL

| Model | Calls | Input | Cached | Output | Total | Cost (RMB) | Unpriced |
|---|---:|---:|---:|---:|---:|---:|---:|
| qwen2.5-7b-instruct | 97 | 715902 | 0 | 9659 | 725561 | Unknown (priced subtotal 0.00000000) | 95 |

## Final Evidence Sufficiency Checks

### Round 1

Configured cut: 1
Stage status: SUCCESS
Check status: INSUFFICIENT
Input final valid Cards: 0
Ignored Cards: 0
Output matches calculation: True
Round limit allows supplement: True
Actual next stage: plan_supplement

| Novelty Point | Valid Cards | Required Cards | Status |
|---|---:|---:|---|
| NP-1 | 0 | 1 | INSUFFICIENT |
| NP-2 | 0 | 1 | INSUFFICIENT |
| NP-3 | 0 | 1 | INSUFFICIENT |

### Round 2

Configured cut: 1
Stage status: SUCCESS
Check status: INSUFFICIENT
Input final valid Cards: 2
Ignored Cards: 0
Output matches calculation: True
Round limit allows supplement: False
Actual next stage: synthesize_report

| Novelty Point | Valid Cards | Required Cards | Status |
|---|---:|---:|---|
| NP-1 | 0 | 1 | INSUFFICIENT |
| NP-2 | 0 | 1 | INSUFFICIENT |
| NP-3 | 2 | 1 | PASS |


## Reviewer Information Adjudication

### Stage stage_0012

Stage status: SUCCESS
Cards preserved: True
Supplement requests control route: False
Missing reviews: []
Unexpected reviews: []
Duplicate reviews: []
Unresolved Evidence IDs: []
Actual next stage: validate_synthesis_input

| Novelty Point | Status | Verdict | Relevant Works | Supplement |
|---|---|---|---:|---|
| NP-1 | insufficient_evidence | - | 0 | True |
| NP-2 | insufficient_evidence | - | 0 | True |
| NP-3 | insufficient_evidence | - | 0 | True |

### Stage stage_0025

Stage status: SUCCESS
Cards preserved: True
Supplement requests control route: False
Missing reviews: []
Unexpected reviews: []
Duplicate reviews: []
Unresolved Evidence IDs: []
Actual next stage: validate_synthesis_input

| Novelty Point | Status | Verdict | Relevant Works | Supplement |
|---|---|---|---:|---|
| NP-1 | insufficient_evidence | - | 0 | True |
| NP-2 | insufficient_evidence | - | 0 | True |
| NP-3 | reviewed | partially_novel | 1 | False |


## Errors

- None

## Integrity Gates

- validate_evidence: PASS
- validate_synthesis_input: PASS
- validate_evidence: PASS
- validate_synthesis_input: PASS
- validate_report_integrity: PASS

## Last Completed Stage

render_report
