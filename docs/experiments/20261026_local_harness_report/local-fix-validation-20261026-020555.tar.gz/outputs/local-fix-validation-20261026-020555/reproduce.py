import asyncio
import json
import os
import sys
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path

ROOT = Path('/home/lya3106643285/projects/Novelty-Multi-Agent-Framework')
sys.path[:0] = [str(ROOT), str(ROOT / 'backend/src'), str(ROOT / 'tests')]
os.environ['NO_PROXY'] = os.environ['no_proxy'] = '127.0.0.1,localhost'

from backend.env import ModelProfile, ModelResponse, OpenAICompatibleChatClient, PromptLibrary
from novelty_agent_framework.agents import SearchPlannerAgent
from novelty_agent_framework.agents.search_plan_compiler import validate_draft_semantics
from novelty_agent_framework.schemas.search_plan_draft import SearchPlanDraft
from test_coordinator_choice_harness import execute
from test_search_planner import make_point, make_task, valid_draft

OUT = ROOT / 'outputs' / ('local-fix-validation-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
OUT.mkdir(parents=True)
print(f'ARTIFACTS={OUT}', flush=True)
client = OpenAICompatibleChatClient(ModelProfile(
    alias='local-fix-validation', model='qwen2.5-7b-instruct',
    base_url='http://127.0.0.1:8000/v1', api_key='local', context_window=32768))
summary = {'model': 'qwen2.5-7b-instruct', 'cloud_calls': 0,
           'literature_requests': 0, 'full_paper_run': False, 'cases': []}

class RecordedClient:
    def __init__(self, name, initial_draft=None):
        self.name = name
        self.calls = []
        self.initial_draft = initial_draft

    def complete(self, messages, *, options=None):
        row = {'messages': [asdict(m) for m in messages], 'options': asdict(options)}
        self.calls.append(row)
        if self.initial_draft is not None:
            row['source'] = 'injected_invalid_draft'
            result = ModelResponse(content=json.dumps(self.initial_draft, ensure_ascii=False))
            self.initial_draft = None
        else:
            row['source'] = 'local_model'
            try:
                result = client.complete(messages, options=replace(
                    options, max_tokens=2048, temperature=0, timeout_seconds=90))
            except Exception as e:
                row['error'] = f'{type(e).__name__}: {e}'
                self.save()
                raise
        row.update(content=result.content, usage=dict(result.usage), raw=dict(result.raw))
        self.save()
        return result

    async def acomplete(self, messages, *, options=None):
        return await asyncio.to_thread(self.complete, messages, options=options)

    def save(self):
        (OUT / f'{self.name}-calls.json').write_text(json.dumps(
            self.calls, ensure_ascii=False, indent=2, default=str) + '\n')

def save_summary():
    (OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')

for kind, expected in [('count', 'research_gap'), ('semantic', 'feature_supplement'), ('zero', 'replan_query')]:
    model = RecordedClient('coordinator-' + kind)
    case_dir = OUT / kind
    case_dir.mkdir()
    os.chdir(case_dir)
    try:
        result, audit, _ = execute(model, kind=kind)
        tasks = result.get('research_tasks', [])
        case = {'name': 'coordinator-' + kind, 'expected_task_type': expected,
                'task_types': [t.task_type for t in tasks],
                'passed': bool(tasks) and all(t.task_type == expected for t in tasks),
                'failure_codes': [e.code.value for e in result.get('failure_events', [])],
                'live_model_calls': len(model.calls)}
        (OUT / f'coordinator-{kind}-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    except Exception as e:
        case = {'name': 'coordinator-' + kind, 'passed': False, 'error': f'{type(e).__name__}: {e}'}
    finally:
        os.chdir(ROOT)
    summary['cases'].append(case)
    save_summary()
    print(json.dumps(case, ensure_ascii=False), flush=True)

for seeded in (False, True):
    task = make_task(language='en')
    draft = valid_draft(task)
    draft['concepts'][0]['terms'] = ['GSAERU模型']
    draft['concepts'][0]['alias'] = ['动态图神经网络']
    name = 'english-repair' if seeded else 'english-generation'
    model = RecordedClient(name, initial_draft=draft if seeded else None)
    issues = validate_draft_semantics(SearchPlanDraft.model_validate(draft), task=task)
    try:
        agent = SearchPlannerAgent(model_client=model,
            prompts=PromptLibrary(ROOT / 'backend/src/novelty_agent_framework/prompts'))
        plan = agent.plan(make_point(), task)
        case = {'name': name, 'passed': True,
                'live_model_calls': sum(c['source'] == 'local_model' for c in model.calls),
                'injected_invalid_draft': seeded,
                'detected_issue_codes': [i.code for i in issues] if seeded else [],
                'terms': [c.terms for c in plan.concepts], 'aliases': [c.alias for c in plan.concepts]}
        (OUT / f'{name}-plan.json').write_text(plan.model_dump_json(indent=2) + '\n')
    except Exception as e:
        case = {'name': name, 'passed': False, 'error': f'{type(e).__name__}: {e}',
                'audit': getattr(e, 'audit', None)}
    summary['cases'].append(case)
    save_summary()
    print(json.dumps(case, ensure_ascii=False), flush=True)

summary['passed'] = all(c['passed'] for c in summary['cases'])
save_summary()
print('ALL_PASSED=' + str(summary['passed']), flush=True)
