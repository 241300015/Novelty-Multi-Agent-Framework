"""Read-only audit of context pressure, Reader work, and missing reference bodies."""
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

from summarize_context import summarize, read, ROOT, RUN
from novelty_agent_framework.diagnostics.contracts import RuntimeDiagnosticContext
from novelty_agent_framework.diagnostics.reader_failures import inspect_reader_failures


def write(name, data):
    (ROOT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def csv_file(name, rows, fields):
    with (ROOT / name).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                             for k, v in row.items() if k in fields})


def audit():
    base = summarize()
    runtime = Path(base['runtime'])
    workspace = RUN / 'MF2033k6lC'

    def restore(value):
        if isinstance(value, dict):
            if value.get('type') == 'content_reference':
                return (runtime / value['path']).read_text()
            return {k: restore(v) for k, v in value.items()}
        if isinstance(value, list):
            return [restore(v) for v in value]
        return value

    calls = []
    for row in base['calls']:
        record = restore(read(ROOT / row['artifact']))
        messages = record.get('request_payload', {}).get('messages', [])
        system = '\n'.join(m.get('content') or '' for m in messages if m.get('role') == 'system')
        category = ('report_synthesis' if row['stage'] == 'synthesize_report' else
                    'review_synthesis' if '查新点级汇总 Reviewer' in system else row['stage'])
        visible_reads = []
        for message in messages:
            content = message.get('content') or ''
            if not isinstance(content, str):
                continue
            if message.get('role') != 'tool' and not content.startswith('Harness observation:'):
                continue
            try:
                observation = json.loads(content[content.index('{'):])
            except (ValueError, TypeError):
                continue
            for item in observation.get('read_results') or [observation.get('read_result', {})]:
                if item.get('text'):
                    visible_reads.append({'read_id': item.get('read_id'), 'artifact_id': item.get('artifact_id'),
                                          'role': item.get('role'), 'chars': len(item['text'])})
        selected_label = None
        if messages and str(messages[-1].get('content', '')).startswith('Current Harness choices'):
            try:
                text = messages[-1]['content']
                menu, _ = json.JSONDecoder().raw_decode(text[text.index('{'):])
                response = json.loads((record.get('response') or {}).get('content') or '{}')
                selected_label = menu.get(response.get('option_id'))
            except (ValueError, TypeError):
                pass
        row.update(category=category, reader_observations_visible=len(visible_reads),
                   reader_text_chars_visible=sum(r['chars'] for r in visible_reads), visible_reads=visible_reads,
                   selected_action_label=selected_label)
        calls.append(row)
    stage_stats = []
    for category in sorted({row['category'] for row in calls}):
        group = [row for row in calls if row['category'] == category]
        peak = max(group, key=lambda r: r['requested_total_tokens'] or 0)
        stage_stats.append({'category': category, 'calls': len(group),
            'failed_calls': sum(r['status'] not in {'SUCCESS', 'RUNNING'} for r in group),
            'measured_overflows': sum(r['measured_overflow'] for r in group),
            'confirmed_context_errors': sum(r['confirmed_context_error'] for r in group),
            'output_limit_reached': sum(r['output_limit_reached'] for r in group),
            'peak_input_tokens': max(r['input_tokens'] or 0 for r in group),
            'peak_requested_tokens': peak['requested_total_tokens'], 'window': peak['context_window'],
            'peak_call_id': peak['call_id'], 'peak_call_artifact': peak['artifact'],
            'max_reader_text_chars_visible': max(r['reader_text_chars_visible'] for r in group)})

    tools = []
    reads = defaultdict(list)
    acquisitions = defaultdict(list)
    for path in sorted((runtime / 'tools').glob('*.json')):
        tool = restore(read(path))
        tools.append(tool)
        args = tool.get('resolved_arguments') or {}
        raw = tool.get('raw_result') or {}
        payload = raw.get('payload') or {}
        source_ids = args.get('full_text_source_record_ids') or []
        if tool.get('tool_name') == 'database_search' and source_ids:
            bundle = payload.get('research_bundle') or {}
            for record_id in source_ids:
                acquisitions[record_id].append({
                    'tool_call_id': tool.get('tool_call_id'), 'execution_status': tool.get('execution_status'),
                    'error': tool.get('error') or raw.get('error'),
                    'warnings': bundle.get('warnings', []), 'failures': bundle.get('execution_failures', []),
                    'returned_body_artifacts': [a['artifact_id'] for a in bundle.get('artifacts', [])
                        if a.get('source_record_id') == record_id and a.get('role') in {'extracted_text', 'full_text'}],
                    'artifact': str(path.relative_to(ROOT)),
                })
        if tool.get('tool_name') == 'reader':
            for item in payload.get('read_results') or [payload.get('read_result', {})]:
                if item.get('artifact_id'):
                    reads[item['artifact_id']].append({
                        'tool_call_id': tool.get('tool_call_id'), 'read_id': item.get('read_id'),
                        'role': item.get('role'), 'char_start': item.get('char_start'),
                        'char_end': item.get('char_end'), 'has_more': item.get('has_more'),
                        'text_chars': len(item.get('text', '')), 'stage': tool.get('stage_name'),
                        'artifact': str(path.relative_to(ROOT)),
                    })

    references = []
    for namespace, folder in [('research_reference', 'references'), ('subject_reference', 'subject_references')]:
        manifest_path = workspace / folder / 'list.json'
        manifest = read(manifest_path)
        for record in manifest.get('source_records', []):
            record_id = record['source_record_id']
            artifacts = [a for a in manifest.get('artifacts', []) if a.get('source_record_id') == record_id]
            bodies = [a for a in artifacts if a.get('role') in {'extracted_text', 'full_text'}]
            readable = [a for a in bodies if str(a.get('media_type', '')).startswith('text/')]
            attempts = acquisitions.get(record_id, [])
            body_reads = [r for a in bodies for r in reads.get(a['artifact_id'], [])]
            artifact_ids = {a['artifact_id'] for a in artifacts}
            skip_decisions = [{'call_id':c['call_id'], 'task_id':(c.get('scope') or {}).get('task_id'),
                               'label':c['selected_action_label'], 'artifact':c['artifact']}
                              for c in calls if c.get('selected_action_label') == '不获取此文献全文，继续处理本轮摘要'
                              and c['visible_reads'] and c['visible_reads'][-1]['artifact_id'] in artifact_ids]
            if any(a.get('content_extent') == 'full' for a in readable):
                status = 'fulltext_available_read' if body_reads else 'fulltext_available_not_read'
            elif readable:
                status = 'partial_or_unknown_extent_text_only'
            elif bodies:
                status = 'binary_fulltext_without_readable_text'
            elif attempts:
                status = 'acquisition_attempted_without_body'
            else:
                status = 'fulltext_not_attempted_in_this_run'
            references.append({
                'namespace': namespace, 'source_record_id': record_id, 'work_id': record.get('work_id'),
                'title': record.get('title'), 'source_id': record.get('source_id'),
                'access_status': record.get('access_status'), 'full_text_url': record.get('full_text_url'),
                'fulltext_status': status, 'acquisition_attempt_count': len(attempts),
                'explicit_skip_decisions': skip_decisions,
                'acquisition_attempts': attempts, 'body_read_count': len(body_reads),
                'body_read_chars': sum(r['text_chars'] for r in body_reads),
                'abstract_read_count': sum(len(reads.get(a['artifact_id'], [])) for a in artifacts if a.get('role') == 'abstract'),
                'body_artifacts': [{k:a.get(k) for k in ('artifact_id', 'role', 'media_type', 'content_extent',
                    'relative_path', 'extraction_warnings')} for a in bodies],
                'manifest': str(manifest_path.relative_to(ROOT)),
            })
    diagnostics = inspect_reader_failures(RuntimeDiagnosticContext(
        paper_id='MF2033k6lC', run_id=runtime.name, workspace=workspace,
        run_dir=runtime, terminal_status=base['run']['status']))
    write('reader-audit.json', diagnostics)
    groups = {}
    for namespace in ('research_reference', 'subject_reference'):
        group = [r for r in references if r['namespace'] == namespace]
        groups[namespace] = {'source_records': len(group),
            'fulltext_status_counts': dict(Counter(r['fulltext_status'] for r in group)),
            'acquisition_attempts': sum(r['acquisition_attempt_count'] for r in group),
            'records_with_explicit_skip': sum(bool(r['explicit_skip_decisions']) for r in group),
            'body_read_count': sum(r['body_read_count'] for r in group)}
    fulltext = {'counts': groups, 'references': references,
        'subject_input': {'input_chars': read(ROOT/'experiment.json')['full_text_input_chars'],
                         **base['workflow_impact']},
        'interpretation': 'Abstract content_extent=full means the abstract is complete, not that the article body was obtained. No acquisition attempt is not a download failure. Subject reference assets can come from the allowed bootstrap cache. Read characters count observations, not unique coverage.'}
    bootstrap_path = workspace / 'subject_references/bootstrap.json'
    bootstrap = read(bootstrap_path)
    canonical = read(ROOT.parents[1] / 'outputs/MF2033k6lC/subject_references/bootstrap.json')
    reference_entries = []
    cached_errors = Counter()
    for entry in bootstrap.get('entries', []):
        errors = []
        for attempt in entry.get('attempts', []):
            error = attempt.get('error') or ''
            if not error:
                continue
            kind = ('HTTP_429' if '429' in error else 'ReadTimeout' if 'ReadTimeout' in error else
                    'ArxivCircuitOpenError' if 'ArxivCircuitOpenError' in error else 'other')
            cached_errors[kind] += 1
            errors.append(kind)
        reference_entries.append({'reference_id':entry['reference_id'], 'ordinal':entry.get('ordinal'),
            'citation':entry.get('raw_reference'), 'resolution_status':entry.get('resolution_status'),
            'resolved_work_id':entry.get('resolved_work_id'), 'cached_attempt_error_types':errors})
    fulltext['subject_reference_bootstrap'] = {
        'entries':len(reference_entries),
        'resolution_counts':dict(Counter(e['resolution_status'] for e in reference_entries)),
        'cached_attempt_error_counts':dict(cached_errors),
        'identical_to_canonical_cache':bootstrap == canonical,
        'retried_in_this_run':False,
        'artifact':str(bootstrap_path.relative_to(ROOT)),
        'interpretation':'The standard entrypoint reused its existing reference-resolution cache. These errors are historical, not failures of new fulltext requests in this run.',
        'references':reference_entries,
    }
    csv_file('subject-reference-status.csv', reference_entries,
             ['reference_id','ordinal','citation','resolution_status','resolved_work_id','cached_attempt_error_types'])
    write('fulltext-audit.json', fulltext)
    csv_file('fulltext-status.csv', references, ['namespace','source_record_id','title','source_id',
        'fulltext_status','acquisition_attempt_count','abstract_read_count','body_read_count','body_read_chars', 'full_text_url'])
    base.update(calls=calls, stage_context_stats=stage_stats, reader_audit=diagnostics['counts'],
        fulltext_summary=groups,
        reader_context_note='Reader is deterministic file I/O. Context pressure is measured in subsequent Researcher/Reviewer model requests containing Reader observations; visible Reader character counts are not per-source token attribution.')
    write('context-audit.json', base)
    csv_file('context-calls.csv', calls, ['call_id','stage','category','status','input_tokens',
        'reserved_output_tokens','requested_total_tokens','context_window','reader_observations_visible',
        'reader_text_chars_visible','measured_overflow','confirmed_context_error','output_limit_reached','artifact'])
    write('audit-summary.json', {'run_status':base['run']['status'],
        'model_calls':base['model_call_count'], 'status_counts':base['call_status_counts'],
        'context_errors':base['confirmed_context_error_count'],'measured_overflows':base['measured_overflow_count'],
        'output_limit_reached':base['output_limit_reached_count'], 'stages':stage_stats,
        'reader':diagnostics['counts'],'fulltext':groups,'workflow_impact':base['workflow_impact'],
        'subject_reference_bootstrap':{k:v for k,v in fulltext['subject_reference_bootstrap'].items() if k != 'references'}})
    print(json.dumps({'stage_context_stats':stage_stats,'reader':diagnostics['counts'],'fulltext':groups},ensure_ascii=False))


if __name__ == '__main__':
    audit()
