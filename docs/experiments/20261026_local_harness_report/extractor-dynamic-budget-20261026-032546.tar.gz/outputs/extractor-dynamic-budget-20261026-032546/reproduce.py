import asyncio
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import traceback
from datetime import datetime
from uuid import uuid4

os.environ['NO_PROXY'] = os.environ['no_proxy'] = '127.0.0.1,localhost'

from backend.env import ModelProfile, ModelCallOptions, OpenAICompatibleChatClient
from novelty_agent_framework.agents.point_extractor import NoveltyPointExtractorAgent
from novelty_agent_framework.workflows import NoveltyWorkflow
from novelty_agent_framework.schemas import PaperInput

root = Path('outputs') / ('extractor-dynamic-budget-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
root.mkdir(parents=True)
def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + '\n')

source = Path('outputs/MF2033k6lC/paper-input/others/paper.json')
paper = PaperInput.model_validate_json(source.read_text())
files = list(Path('backend/src/novelty_agent_framework/prompts/extractor').glob('*.md'))
files += [Path('backend/src/novelty_agent_framework/core/extractor_harness.py'),
          Path('backend/src/novelty_agent_framework/agents/point_extractor.py')]
hashes = {}
for path in files:
    target = root / 'source_snapshot' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
shutil.copyfile(__file__, root / 'reproduce.py')
manifest = {'scope': 'One real local extraction-only run after Harness migration and dynamic reading budget; no retrieval or report generation',
    'paper_id': paper.paper_id, 'input': str(source),
    'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'working_tree_sources': hashes, 'model': 'qwen2.5-7b-instruct',
    'base_url': 'http://127.0.0.1:8000/v1', 'temperature': 0,
    'max_tokens': 4096, 'timeout_seconds': 120, 'context_window': 32768,
    'fallback_profiles': [], 'cloud_calls': 0, 'started_at': datetime.now().isoformat()}
write(root / 'experiment.json', manifest)
print('OUTPUT_ROOT=' + str(root), flush=True)
summaries = []
for number in range(1, 2):
    run_root = root / 'runs' / f'{number:04d}'
    run_root.mkdir(parents=True)
    calls = []
    base = OpenAICompatibleChatClient(ModelProfile(alias='local-extractor-retest',
        model=manifest['model'], base_url=manifest['base_url'], api_key='local', context_window=32768))
    class Local:
        def complete(self, messages, *, options=None):
            user = messages[-1].content
            context = json.loads(user[user.index('{'):])
            call = {'number': len(calls) + 1, 'phase': context.get('phase'),
                    'started_at': datetime.now().isoformat(),
                    'has_digest': 'digest' in context,
                    'digest_excerpt_chars': len(context.get('digest', {}).get('full_text_excerpt', '')),
                    'content_list_count': len(context.get('content_list', [])),
                    'read_chars': sum(len(r['text']) for r in context.get('reads', [])),
                    'read_budget': context.get('read_budget')}
            calls.append(call)
            print(f'run={number} call={len(calls)} phase={call["phase"]}', flush=True)
            started = time.monotonic()
            try:
                response = base.complete(messages, options=options)
                call.update(status='completed', usage=dict(response.usage), raw=dict(response.raw))
                return response
            except Exception as exc:
                call.update(status='failed', error_type=type(exc).__name__, error=str(exc))
                raise
            finally:
                call['elapsed_seconds'] = round(time.monotonic() - started, 3)
                write(run_root / 'model-calls.json', calls)
    workflow = NoveltyWorkflow.default(output_root=run_root)
    workflow.point_extractor = NoveltyPointExtractorAgent(Local(), harness_config={'enabled': True},
        model_options=ModelCallOptions(temperature=0, max_tokens=4096, timeout_seconds=120))
    summary = {'run': number, 'run_id': 'run-' + uuid4().hex,
               'started_at': datetime.now().isoformat(), 'cloud_calls': 0}
    started = time.monotonic()
    try:
        result = asyncio.run(workflow._extract_points({'paper': paper, 'run_id': summary['run_id']}))
        summary.update(status='completed', points=[p.model_dump(mode='json') for p in result['novelty_points']],
                       issues=[i.model_dump(mode='json') for i in result['issues']])
    except Exception as exc:
        summary.update(status='failed', error_type=type(exc).__name__, error=str(exc))
        (run_root / 'error.txt').write_text(traceback.format_exc())
    finally:
        trace = workflow.point_extractor.last_trace or {}
        write(run_root / 'trace.json', trace)
        versions = trace.get('versions', [])
        summary.update(elapsed_seconds=round(time.monotonic() - started, 3),
            phases=[c['phase'] for c in calls], model_calls=len(calls),
            failed_model_calls=sum(c.get('status') == 'failed' for c in calls),
            initial_count=len(versions[0]['points']) if versions else None,
            final_count=trace.get('final_count'),
            post_generation_reading=trace.get('post_generation_reading'),
            execution_status=trace.get('execution_status'), exit_reason=trace.get('exit_reason'),
            coverage_complete=trace.get('coverage_complete'),
            semantic_completeness_verified=trace.get('semantic_completeness_verified'),
            budgets=trace.get('budgets'), events=trace.get('events'))
        write(run_root / 'summary.json', summary)
        summaries.append(summary)
        write(root / 'summary.json', summaries)
        print('RESULT=' + json.dumps({k: v for k, v in summary.items() if k not in ('points', 'events', 'issues')}, ensure_ascii=False), flush=True)
manifest['finished_at'] = datetime.now().isoformat()
manifest['sources_unchanged'] = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in hashes.items())
write(root / 'experiment.json', manifest)
print('DONE=' + str(root), flush=True)
